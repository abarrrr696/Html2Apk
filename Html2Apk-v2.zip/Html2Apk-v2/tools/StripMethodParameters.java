import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

/**
 * Membuang atribut MethodParameters dari semua .class di sebuah folder.
 * Perlu karena javac 21 menulis atribut ini (tanpa nama parameter) untuk konstruktor kelas dalam,
 * dan d8 lama dari build-tools 33 crash dengan NullPointerException saat membacanya.
 * Pemakaian: java tools/StripMethodParameters.java out/t/obj
 */
public class StripMethodParameters {
    public static void main(String[] args) throws IOException {
        int total = 0, changed = 0;
        List<Path> files;
        try (Stream<Path> st = Files.walk(Paths.get(args[0]))) {
            files = st.filter(p -> p.toString().endsWith(".class")).collect(Collectors.toList());
        }
        for (Path p : files) {
            byte[] in = Files.readAllBytes(p);
            byte[] out = strip(in);
            total++;
            if (out != in) { Files.write(p, out); changed++; }
        }
        System.out.println("StripMethodParameters: " + changed + " dari " + total + " kelas diperbaiki");
    }

    static byte[] strip(byte[] b) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(b));
        ByteArrayOutputStream bo = new ByteArrayOutputStream(b.length);
        DataOutputStream out = new DataOutputStream(bo);
        out.writeInt(in.readInt());
        out.writeShort(in.readUnsignedShort());
        out.writeShort(in.readUnsignedShort());
        int cp = in.readUnsignedShort();
        out.writeShort(cp);
        String[] utf = new String[cp];
        for (int i = 1; i < cp; i++) {
            int tag = in.readUnsignedByte();
            out.writeByte(tag);
            switch (tag) {
                case 1: { String s = in.readUTF(); utf[i] = s; out.writeUTF(s); break; }
                case 3: case 4: case 9: case 10: case 11: case 12: case 17: case 18:
                    out.writeInt(in.readInt()); break;
                case 5: case 6:
                    out.writeLong(in.readLong()); i++; break;
                case 7: case 8: case 16: case 19: case 20:
                    out.writeShort(in.readUnsignedShort()); break;
                case 15:
                    out.writeByte(in.readUnsignedByte()); out.writeShort(in.readUnsignedShort()); break;
                default: throw new IOException("Tag constant pool tidak dikenal: " + tag);
            }
        }
        for (int i = 0; i < 3; i++) out.writeShort(in.readUnsignedShort());   // access, this, super
        int ifc = in.readUnsignedShort();
        out.writeShort(ifc);
        for (int i = 0; i < ifc; i++) out.writeShort(in.readUnsignedShort());
        boolean removed = false;
        for (int pass = 0; pass < 2; pass++) {                                // 0 = fields, 1 = methods
            int n = in.readUnsignedShort();
            out.writeShort(n);
            for (int i = 0; i < n; i++) {
                out.writeShort(in.readUnsignedShort());                       // access
                out.writeShort(in.readUnsignedShort());                       // name
                out.writeShort(in.readUnsignedShort());                       // descriptor
                int ac = in.readUnsignedShort();
                List<byte[]> keep = new ArrayList<byte[]>();
                List<Integer> keepName = new ArrayList<Integer>();
                for (int k = 0; k < ac; k++) {
                    int nameIdx = in.readUnsignedShort();
                    int len = in.readInt();
                    byte[] data = new byte[len];
                    in.readFully(data);
                    if (pass == 1 && "MethodParameters".equals(utf[nameIdx])) { removed = true; continue; }
                    keep.add(data); keepName.add(nameIdx);
                }
                out.writeShort(keep.size());
                for (int k = 0; k < keep.size(); k++) {
                    out.writeShort(keepName.get(k));
                    out.writeInt(keep.get(k).length);
                    out.write(keep.get(k));
                }
            }
        }
        byte[] tail = in.readAllBytes();                                      // atribut tingkat kelas
        out.write(tail);
        out.flush();
        return removed ? bo.toByteArray() : b;
    }
}
