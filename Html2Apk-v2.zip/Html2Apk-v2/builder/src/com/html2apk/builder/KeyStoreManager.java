package com.html2apk.builder;

import java.io.*;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Membuat dan menyimpan key penandatangan APK (RSA 3072, SHA-256, berlaku 30 tahun)
 * di PKCS12 dengan password acak. Satu key dipakai berulang supaya APK bisa di-update.
 */
final class KeyStoreManager {
    static final String ALIAS = "html2apk";
    final PrivateKey key;
    final X509Certificate cert;
    final File p12File;
    final String password;

    private KeyStoreManager(PrivateKey k, X509Certificate c, File f, String pw) {
        key = k; cert = c; p12File = f; password = pw;
    }

    static boolean exists(File dir) {
        return new File(dir, "html2apk.p12").exists() && new File(dir, "html2apk.pw").exists();
    }

    /** Sidik jari SHA-256 sertifikat, 8 byte pertama, format AB:CD:... */
    String fingerprint() throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(cert.getEncoded());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            if (i > 0) sb.append(':');
            sb.append(String.format("%02X", d[i] & 0xFF));
        }
        return sb.toString();
    }

    static KeyStoreManager loadOrCreate(File dir) throws Exception {
        File ks = new File(dir, "html2apk.p12");
        File pw = new File(dir, "html2apk.pw");
        if (!ks.exists() || !pw.exists()) create(ks, pw);
        String pass = readText(pw).trim();
        KeyStore k = KeyStore.getInstance("PKCS12");
        InputStream in = new FileInputStream(ks);
        try { k.load(in, pass.toCharArray()); } finally { in.close(); }
        PrivateKey pk = (PrivateKey) k.getKey(ALIAS, pass.toCharArray());
        X509Certificate c = (X509Certificate) k.getCertificate(ALIAS);
        return new KeyStoreManager(pk, c, ks, pass);
    }

    private static void create(File ks, File pwFile) throws Exception {
        SecureRandom rnd = new SecureRandom();
        byte[] pwBytes = new byte[18];
        rnd.nextBytes(pwBytes);
        String pass = android_free_b64(pwBytes);

        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(3072, rnd);
        KeyPair kp = g.generateKeyPair();
        X509Certificate cert = selfSign(kp, "Html2Apk Signing Key", rnd);

        KeyStore k = KeyStore.getInstance("PKCS12");
        k.load(null, null);
        k.setKeyEntry(ALIAS, kp.getPrivate(), pass.toCharArray(), new Certificate[]{cert});
        FileOutputStream fo = new FileOutputStream(ks);
        try { k.store(fo, pass.toCharArray()); } finally { fo.close(); }
        FileOutputStream fp = new FileOutputStream(pwFile);
        try { fp.write(pass.getBytes("UTF-8")); } finally { fp.close(); }
        for (File f : new File[]{ks, pwFile}) {
            f.setReadable(false, false); f.setReadable(true, true);
            f.setWritable(false, false); f.setWritable(true, true);
        }
    }

    private static String android_free_b64(byte[] b) {
        String abc = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(abc.charAt((x & 0xFF) % abc.length()));
        return sb.toString();
    }

    private static String readText(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[1024]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toString("UTF-8");
        } finally { in.close(); }
    }

    // ---- Sertifikat X.509 v3 self-signed, dirakit manual (DER) ----

    static X509Certificate selfSign(KeyPair kp, String cn, SecureRandom rnd) throws Exception {
        byte[] sigAlg = seq(cat(new byte[]{0x06, 0x09, 0x2A, (byte) 0x86, 0x48, (byte) 0x86, (byte) 0xF7, 0x0D, 0x01, 0x01, 0x0B},
                                new byte[]{0x05, 0x00}));
        byte[] serial = new byte[16];
        rnd.nextBytes(serial);
        serial[0] = (byte) ((serial[0] & 0x3F) | 0x40);
        byte[] name = seq(set(seq(cat(new byte[]{0x06, 0x03, 0x55, 0x04, 0x03}, tlv(0x0C, cn.getBytes("UTF-8"))))));

        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        Date notBefore = new Date(c.getTimeInMillis() - 24L * 3600 * 1000);
        c.add(Calendar.YEAR, 30);
        Date notAfter = c.getTime();
        byte[] validity = seq(cat(time(notBefore), time(notAfter)));

        byte[] tbs = seq(cat(
                new byte[]{(byte) 0xA0, 0x03, 0x02, 0x01, 0x02},
                tlv(0x02, serial), sigAlg, name, validity, name,
                kp.getPublic().getEncoded()));

        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();
        byte[] bitString = tlv(0x03, cat(new byte[]{0x00}, sig));
        byte[] der = seq(cat(tbs, sigAlg, bitString));
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        return (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(der));
    }

    private static byte[] time(Date d) throws Exception {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.setTime(d);
        boolean gen = c.get(Calendar.YEAR) >= 2050;
        SimpleDateFormat f = new SimpleDateFormat(gen ? "yyyyMMddHHmmss'Z'" : "yyMMddHHmmss'Z'");
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return tlv(gen ? 0x18 : 0x17, f.format(d).getBytes("US-ASCII"));
    }

    private static byte[] seq(byte[] b) { return tlv(0x30, b); }
    private static byte[] set(byte[] b) { return tlv(0x31, b); }

    private static byte[] tlv(int tag, byte[] v) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int n = v.length;
        if (n < 128) o.write(n);
        else if (n < 256) { o.write(0x81); o.write(n); }
        else if (n < 65536) { o.write(0x82); o.write(n >> 8); o.write(n & 0xFF); }
        else { o.write(0x83); o.write(n >> 16); o.write((n >> 8) & 0xFF); o.write(n & 0xFF); }
        o.write(v, 0, v.length);
        return o.toByteArray();
    }

    private static byte[] cat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }
}
