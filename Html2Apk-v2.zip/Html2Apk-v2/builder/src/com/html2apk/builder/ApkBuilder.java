package com.html2apk.builder;

import java.io.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Merakit APK (belum ditandatangani) dari template.apk + file HTML pengguna. Murni Java. */
final class ApkBuilder {
    static final String PH_PKG = "com.html2apk.placeholder";
    static final String PH_NAME = "__APP_NAME__";
    static final String PH_VERSION = "0.0.0-placeholder";
    static final String ICON_ENTRY = "res/drawable/ic_launcher.png";
    private static final Pattern PKG = Pattern.compile("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$");

    interface Asset {
        String path();                      // relatif terhadap www/, pakai '/'
        byte[] read() throws IOException;
    }

    static final class Config {
        String appName, pkg, versionName, license, extraConfig;
        int versionCode = 1;
        byte[] iconPng;                     // opsional, 192x192
    }

    /** @return kunci pesan (lihat I18n, awalan "v."), atau null jika semuanya benar. */
    static String validate(Config c, String ownPackage) {
        if (c.appName == null || c.appName.trim().isEmpty()) return "v.name";
        if (c.appName.length() > 60) return "v.namelong";
        if (c.pkg == null || !PKG.matcher(c.pkg).matches()) return "v.pkg";
        if (c.pkg.length() > 120) return "v.pkglen";
        if (c.pkg.equals(ownPackage) || c.pkg.equals(PH_PKG)) return "v.pkgown";
        if (c.versionName == null || c.versionName.trim().isEmpty() || c.versionName.length() > 40) return "v.ver";
        if (c.versionCode < 1) return "v.code";
        return null;
    }

    static void buildUnsigned(File template, List<Asset> www, Config c, File out) throws IOException {
        Map<String, String> rep = new HashMap<String, String>();
        rep.put(PH_PKG, c.pkg);
        rep.put(PH_NAME, c.appName.trim());
        rep.put(PH_VERSION, c.versionName.trim());

        boolean ok = false;
        ZipFile zf = new ZipFile(template);
        ZipWriter z = new ZipWriter(new BufferedOutputStream(new FileOutputStream(out)));
        try {
            boolean manifest = false;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (e.isDirectory() || n.startsWith("META-INF/") || n.startsWith("assets/www/")) continue;
                byte[] data = readAll(zf.getInputStream(e));
                if (n.equals("AndroidManifest.xml")) {
                    data = AxmlPatcher.patch(data, rep, c.versionCode);
                    manifest = true;
                } else if (n.equals(ICON_ENTRY) && c.iconPng != null) {
                    data = c.iconPng;
                }
                z.add(n, data, n.equals("resources.arsc"));
            }
            if (!manifest) throw new IOException("template.apk is broken: no AndroidManifest.xml");

            boolean hasIndex = false;
            for (Asset a : www) {
                String p = a.path();
                if (p.startsWith("/") || p.contains("..") || p.isEmpty()) throw new IOException("Unsafe file name: " + p);
                if (p.equals("index.html")) hasIndex = true;
                z.add("assets/www/" + p, a.read(), false);
            }
            if (!hasIndex) throw new IOException("index.html is missing");
            if (c.extraConfig != null && !c.extraConfig.isEmpty())
                z.add("assets/config.properties", c.extraConfig.getBytes("UTF-8"), false);
            if (c.license != null && !c.license.trim().isEmpty())
                z.add("assets/LICENSE.txt", c.license.trim().getBytes("UTF-8"), false);
            ok = true;
        } finally {
            try { zf.close(); } catch (IOException ignored) {}
            if (ok) z.close();
            else { try { z.close(); } catch (IOException ignored) {} out.delete(); }
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toByteArray();
        } finally {
            in.close();
        }
    }
}
