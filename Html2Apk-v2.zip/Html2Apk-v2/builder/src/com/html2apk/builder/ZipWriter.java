package com.html2apk.builder;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;
import java.util.zip.CRC32;
import java.util.zip.Deflater;

/**
 * Penulis ZIP sederhana tanpa data descriptor.
 * Entry STORED dirapikan ke batas 4 byte (syarat resources.arsc di Android 11+).
 */
final class ZipWriter implements Closeable {
    private static final int DOS_DATE = ((2026 - 1980) << 9) | (1 << 5) | 1;
    private final OutputStream out;
    private long pos = 0;
    private int count = 0;
    private final ByteArrayOutputStream central = new ByteArrayOutputStream();
    private final Set<String> names = new HashSet<String>();

    ZipWriter(OutputStream out) {
        this.out = out;
    }

    void add(String name, byte[] data, boolean store) throws IOException {
        if (!names.add(name)) throw new IOException("Entri ganda di ZIP: " + name);
        byte[] nameB = name.getBytes("UTF-8");
        CRC32 crc = new CRC32();
        crc.update(data, 0, data.length);

        byte[] body = data;
        int method = 0;
        if (!store && data.length > 64) {
            byte[] def = deflate(data);
            if (def.length < data.length) {
                body = def;
                method = 8;
            }
        }

        int extraLen = 0;
        if (method == 0) {
            int pad = (int) ((4 - ((pos + 30 + nameB.length) % 4)) % 4);
            extraLen = pad == 0 ? 0 : pad + 4;
        }

        ByteBuffer lh = ByteBuffer.allocate(30).order(ByteOrder.LITTLE_ENDIAN);
        lh.putInt(0x04034b50).putShort((short) 20).putShort((short) 0x0800)
          .putShort((short) method).putShort((short) 0).putShort((short) DOS_DATE)
          .putInt((int) crc.getValue()).putInt(body.length).putInt(data.length)
          .putShort((short) nameB.length).putShort((short) extraLen);
        long localOffset = pos;
        write(lh.array());
        write(nameB);
        if (extraLen > 0) {
            ByteBuffer ex = ByteBuffer.allocate(extraLen).order(ByteOrder.LITTLE_ENDIAN);
            ex.putShort((short) 0xD935).putShort((short) (extraLen - 4));
            write(ex.array());
        }
        write(body);

        ByteBuffer ch = ByteBuffer.allocate(46).order(ByteOrder.LITTLE_ENDIAN);
        ch.putInt(0x02014b50).putShort((short) 20).putShort((short) 20).putShort((short) 0x0800)
          .putShort((short) method).putShort((short) 0).putShort((short) DOS_DATE)
          .putInt((int) crc.getValue()).putInt(body.length).putInt(data.length)
          .putShort((short) nameB.length).putShort((short) 0).putShort((short) 0)
          .putShort((short) 0).putShort((short) 0).putInt(0).putInt((int) localOffset);
        central.write(ch.array());
        central.write(nameB);
        count++;
    }

    private void write(byte[] b) throws IOException {
        out.write(b);
        pos += b.length;
    }

    private static byte[] deflate(byte[] data) {
        Deflater d = new Deflater(Deflater.BEST_COMPRESSION, true);
        d.setInput(data);
        d.finish();
        ByteArrayOutputStream bo = new ByteArrayOutputStream(data.length / 2 + 16);
        byte[] buf = new byte[16384];
        while (!d.finished()) {
            int n = d.deflate(buf);
            bo.write(buf, 0, n);
        }
        d.end();
        return bo.toByteArray();
    }

    @Override
    public void close() throws IOException {
        long cdOffset = pos;
        byte[] cd = central.toByteArray();
        write(cd);
        ByteBuffer e = ByteBuffer.allocate(22).order(ByteOrder.LITTLE_ENDIAN);
        e.putInt(0x06054b50).putShort((short) 0).putShort((short) 0)
         .putShort((short) count).putShort((short) count)
         .putInt(cd.length).putInt((int) cdOffset).putShort((short) 0);
        write(e.array());
        out.flush();
        out.close();
    }
}
