package com.html2apk.builder;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Saklar gambar sendiri: trek bulat, bulatan geser, tanpa animasi dan bayangan. */
final class ToggleView extends View {
    interface OnChange { void changed(boolean on); }

    private boolean on;
    private final OnChange cb;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    ToggleView(Context c, boolean initial, OnChange change) {
        super(c);
        on = initial;
        cb = change;
        setClickable(true);
        setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                on = !on;
                invalidate();
                if (cb != null) cb.changed(on);
            }
        });
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(Ui.dp(getContext(), 46), Ui.dp(getContext(), 28));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight(), line = Math.max(1, Ui.dp(getContext(), 1));
        float r = h / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(on ? Ui.TEXT : Ui.RAISED);
        rect.set(0, 0, w, h);
        cv.drawRoundRect(rect, r, r, paint);
        if (!on) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(line);
            paint.setColor(Ui.LINE);
            rect.set(line / 2, line / 2, w - line / 2, h - line / 2);
            cv.drawRoundRect(rect, r, r, paint);
        }
        float pad = Ui.dp(getContext(), 4);
        float tr = r - pad;
        float cx = on ? w - r : r;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(on ? Ui.BG : Ui.MUTED);
        cv.drawCircle(cx, h / 2f, tr, paint);
    }
}
