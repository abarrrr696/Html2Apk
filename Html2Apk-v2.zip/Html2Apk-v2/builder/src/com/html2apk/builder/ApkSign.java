package com.html2apk.builder;

import com.android.apksig.ApkSigner;
import java.io.File;
import java.util.Collections;

/** Menandatangani APK dengan skema v1 + v2 + v3 (apksig dari Android build-tools). */
final class ApkSign {
    private ApkSign() {}

    static void sign(File in, File out, KeyStoreManager km) throws Exception {
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder(
                "html2apk", km.key, Collections.singletonList(km.cert)).build();
        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in)
                .setOutputApk(out)
                .setMinSdkVersion(21)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(true)
                .build()
                .sign();
    }
}
