package com.html2apk.builder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Penambal AndroidManifest.xml biner (AXML): mengganti string placeholder
 * di string pool dan mengisi versionCode. Tanpa aapt, murni Java.
 */
final class AxmlPatcher {
    private static final int TYPE_XML = 0x0003;
    private static final int TYPE_POOL = 0x0001;
    private static final int TYPE_START_ELEMENT = 0x0102;
    private static final int UTF8_FLAG = 0x100;

    private AxmlPatcher() {}

    static byte[] patch(byte[] src, Map<String, String> replace, int versionCode) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(src).order(ByteOrder.LITTLE_ENDIAN);
        if (src.length < 40 || (b.getShort(0) & 0xFFFF) != TYPE_XML) throw new IOException("Manifest template bukan AXML");
        int poolOff = 8;
        if ((b.getShort(poolOff) & 0xFFFF) != TYPE_POOL) throw new IOException("String pool tidak ditemukan");
        int poolSize = b.getInt(poolOff + 4);
        int strCount = b.getInt(poolOff + 8);
        int styleCount = b.getInt(poolOff + 12);
        int flags = b.getInt(poolOff + 16);
        int strStart = b.getInt(poolOff + 20);
        if (styleCount != 0) throw new IOException("Style pool tidak didukung");
        boolean utf8 = (flags & UTF8_FLAG) != 0;

        String[] ss = new String[strCount];
        for (int i = 0; i < strCount; i++) {
            int off = poolOff + strStart + b.getInt(poolOff + 28 + 4 * i);
            ss[i] = utf8 ? readUtf8(b, off) : readUtf16(b, off);
        }

        Set<String> found = new HashSet<String>();
        int versionCodeIdx = -1;
        for (int i = 0; i < strCount; i++) {
            if (replace.containsKey(ss[i])) {
                found.add(ss[i]);
                ss[i] = replace.get(ss[i]);
            }
        }
        for (int i = 0; i < strCount; i++) if ("versionCode".equals(ss[i])) versionCodeIdx = i;
        if (found.size() != replace.size()) throw new IOException("Placeholder tidak lengkap di template");
        if (versionCodeIdx < 0) throw new IOException("Atribut versionCode tidak ada di template");

        // Susun ulang string pool.
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offsets = new int[strCount];
        for (int i = 0; i < strCount; i++) {
            offsets[i] = data.size();
            encode(data, ss[i], utf8);
        }
        while (data.size() % 4 != 0) data.write(0);
        int newStrStart = 28 + 4 * strCount;
        int newPoolSize = newStrStart + data.size();

        ByteBuffer pool = ByteBuffer.allocate(newPoolSize).order(ByteOrder.LITTLE_ENDIAN);
        pool.putShort((short) TYPE_POOL).putShort((short) 28).putInt(newPoolSize)
            .putInt(strCount).putInt(0).putInt(flags).putInt(newStrStart).putInt(0);
        for (int i = 0; i < strCount; i++) pool.putInt(offsets[i]);
        pool.put(data.toByteArray());

        byte[] rest = Arrays.copyOfRange(src, poolOff + poolSize, src.length);
        patchVersionCode(rest, versionCodeIdx, versionCode);

        ByteBuffer outBuf = ByteBuffer.allocate(8 + newPoolSize + rest.length).order(ByteOrder.LITTLE_ENDIAN);
        outBuf.putShort((short) TYPE_XML).putShort((short) 8).putInt(8 + newPoolSize + rest.length);
        outBuf.put(pool.array()).put(rest);
        return outBuf.array();
    }

    private static void patchVersionCode(byte[] rest, int nameIdx, int value) throws IOException {
        ByteBuffer r = ByteBuffer.wrap(rest).order(ByteOrder.LITTLE_ENDIAN);
        int pos = 0;
        boolean done = false;
        while (pos + 8 <= rest.length) {
            int type = r.getShort(pos) & 0xFFFF;
            int size = r.getInt(pos + 4);
            if (size < 8) break;
            if (type == TYPE_START_ELEMENT) {
                int attrStart = r.getShort(pos + 24) & 0xFFFF;
                int attrSize = r.getShort(pos + 26) & 0xFFFF;
                int attrCount = r.getShort(pos + 28) & 0xFFFF;
                for (int i = 0; i < attrCount; i++) {
                    int a = pos + 16 + attrStart + i * attrSize;
                    int ns = r.getInt(a);
                    int name = r.getInt(a + 4);
                    if (ns != -1 && name == nameIdx) {
                        r.putInt(a + 8, -1);            // rawValue
                        r.putShort(a + 12, (short) 8);  // typedValue.size
                        r.put(a + 14, (byte) 0);
                        r.put(a + 15, (byte) 0x10);     // TYPE_INT_DEC
                        r.putInt(a + 16, value);
                        done = true;
                    }
                }
            }
            pos += size;
        }
        if (!done) throw new IOException("versionCode tidak ditemukan di manifest");
    }

    private static String readUtf16(ByteBuffer b, int off) {
        int len = b.getShort(off) & 0xFFFF;
        off += 2;
        if ((len & 0x8000) != 0) {
            len = ((len & 0x7FFF) << 16) | (b.getShort(off) & 0xFFFF);
            off += 2;
        }
        char[] c = new char[len];
        for (int i = 0; i < len; i++) c[i] = (char) (b.getShort(off + i * 2) & 0xFFFF);
        return new String(c);
    }

    private static String readUtf8(ByteBuffer b, int off) throws IOException {
        int l1 = b.get(off++) & 0xFF;
        if ((l1 & 0x80) != 0) off++;
        int l2 = b.get(off++) & 0xFF;
        if ((l2 & 0x80) != 0) {
            l2 = ((l2 & 0x7F) << 8) | (b.get(off++) & 0xFF);
        }
        byte[] x = new byte[l2];
        for (int i = 0; i < l2; i++) x[i] = b.get(off + i);
        return new String(x, "UTF-8");
    }

    private static void encode(ByteArrayOutputStream o, String s, boolean utf8) throws IOException {
        if (utf8) {
            byte[] x = s.getBytes("UTF-8");
            writeLen8(o, s.length());
            writeLen8(o, x.length);
            o.write(x);
            o.write(0);
        } else {
            int n = s.length();
            if (n > 0x7FFF) {
                int hi = (n >> 16) | 0x8000;
                o.write(hi & 0xFF); o.write((hi >> 8) & 0xFF);
                o.write(n & 0xFF); o.write((n >> 8) & 0xFF);
            } else {
                o.write(n & 0xFF); o.write((n >> 8) & 0xFF);
            }
            for (int i = 0; i < n; i++) {
                char c = s.charAt(i);
                o.write(c & 0xFF); o.write((c >> 8) & 0xFF);
            }
            o.write(0); o.write(0);
        }
    }

    private static void writeLen8(ByteArrayOutputStream o, int n) {
        if (n > 0x7F) {
            o.write(((n >> 8) & 0x7F) | 0x80);
            o.write(n & 0xFF);
        } else {
            o.write(n);
        }
    }
}
