package com.html2apk.builder;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Html2Apk 2: alur empat langkah. Semua tampilan dibuat lewat kode, tanpa layout XML. */
public class MainActivity extends Activity {
    private static final int REQ_HTML = 1, REQ_DIR = 2, REQ_ICON = 3, REQ_BACKUP = 4;
    private static final int STEPS = 4;
    private static final int MAX_FILES = 5000;
    private static final long BIG = 150L * 1024 * 1024;
    private static final int[] SWATCH = {0xFF000000, 0xFF1C1C1E, 0xFFFFFFFF, 0xFFF2F0EB, 0xFF1F2A44, 0xFF1E3A2F};

    private static final class State {
        Uri source;
        boolean isDir, hasIndex, scanning;
        String srcName = "", entryHtml;
        int fileCount;
        long bytes;

        String name = "", pkg = "", verName = "1.0.0", license = "";
        int verCode = 1;
        boolean pkgTouched;
        byte[] iconPng;
        Bitmap iconThumb;

        int orientation = 0, colorIdx = 0;
        boolean fullscreen, keepOn, zoom, offline, ext = true;

        String error, fingerprint;
        boolean building, done, fpLoading;
        int progress;
        Uri outUri;
        String outName;
    }

    private final State s = new State();
    private int step = 0;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private EditText etPkg;
    private boolean settingPkg;

    // ------------------------------------------------------------ helpers

    private abstract static class Act implements View.OnClickListener {
        public void onClick(View v) { run(); }
        abstract void run();
    }

    private abstract static class Watch implements TextWatcher {
        public void beforeTextChanged(CharSequence a, int b, int c, int d) {}
        public void onTextChanged(CharSequence a, int b, int c, int d) {}
        public void afterTextChanged(Editable e) { changed(e.toString()); }
        abstract void changed(String text);
    }

    private int dp(float v) { return Ui.dp(this, v); }

    private static String t(String k) { return I18n.t(k); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("html2apk", MODE_PRIVATE);
        String lang = prefs.getString("lang", null);
        if (lang == null) {
            String l = Locale.getDefault().getLanguage();
            lang = (l.equals("in") || l.equals("id")) ? "id" : "en";
        }
        I18n.en = lang.equals("en");
        render(false);
    }

    private void render(boolean keepScroll) {
        final int y = (keepScroll && scroll != null) ? scroll.getScrollY() : 0;
        setContentView(buildScreen());
        if (y > 0) {
            scroll.post(new Runnable() { public void run() { scroll.scrollTo(0, y); } });
        }
    }

    private void renderUi(final boolean keepScroll) {
        runOnUiThread(new Runnable() { public void run() { render(keepScroll); } });
    }

    // ------------------------------------------------------------- layout

    private View buildScreen() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Ui.BG);
        page.addView(topBar());

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(10), dp(20), dp(28));
        scroll.addView(body, Ui.lp(Ui.MATCH, Ui.WRAP));

        body.addView(stepHeader());
        if (s.error != null) body.addView(errorBox(s.error));
        etPkg = null;
        if (step == 0) stepSource(body);
        else if (step == 1) stepApp(body);
        else if (step == 2) stepOptions(body);
        else stepReview(body);

        page.addView(scroll, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));
        page.addView(Ui.hline(this));
        page.addView(bottomBar());
        return page;
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(20), dp(16), dp(20), dp(6));

        bar.addView(Ui.text(this, "Html2Apk", 17, Ui.TEXT, true, true));
        bar.addView(Ui.text(this, "2.0", 11, Ui.DIM, false, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 8, 3, 0, 0));
        View spacer = new View(this);
        bar.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        final TextView[] langs = new TextView[2];
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.setBackground(Ui.box(this, Ui.SURFACE, Ui.LINE, 8));
        seg.setPadding(dp(2), dp(2), dp(2), dp(2));
        String[] labels = {"ID", "EN"};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            TextView tv = Ui.text(this, labels[i], 12, Ui.MUTED, true, true);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(dp(11), dp(6), dp(11), dp(6));
            tv.setOnClickListener(new Act() {
                void run() {
                    I18n.en = (idx == 1);
                    prefs.edit().putString("lang", idx == 1 ? "en" : "id").apply();
                    render(true);
                }
            });
            langs[i] = tv;
            seg.addView(tv);
        }
        styleSegment(langs, I18n.en ? 1 : 0, 6);
        bar.addView(seg);
        return bar;
    }

    private void styleSegment(TextView[] items, int sel, float radiusDp) {
        for (int i = 0; i < items.length; i++) {
            boolean on = i == sel;
            items[i].setTextColor(on ? Ui.BG : Ui.MUTED);
            items[i].setBackground(on ? Ui.box(this, Ui.TEXT, 0, radiusDp) : null);
        }
    }

    private View stepHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(0, dp(8), 0, dp(18));

        LinearLayout segs = new LinearLayout(this);
        segs.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < STEPS; i++) {
            View v = new View(this);
            v.setBackgroundColor(i <= step ? Ui.TEXT : Ui.LINE);
            segs.addView(v, Ui.weight(this, 1f, 0, 0, i < STEPS - 1 ? 4 : 0, 0));
            ((LinearLayout.LayoutParams) v.getLayoutParams()).height = dp(3);
        }
        h.addView(segs);
        h.addView(Ui.text(this, String.format(Locale.ROOT, "%02d / %02d", step + 1, STEPS), 12, Ui.MUTED, false, true),
                Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 14, 0, 0));
        h.addView(Ui.text(this, t("s" + step + ".title"), 26, Ui.TEXT, true, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 8, 0, 0));
        h.addView(Ui.text(this, t("s" + step + ".sub"), 14, Ui.MUTED, false, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 8, 0, 0));
        return h;
    }

    private View errorBox(String msg) {
        TextView e = Ui.text(this, msg, 13, Ui.BAD, false, false);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(Ui.box(this, Ui.SURFACE, Ui.BAD, 10));
        e.setLayoutParams(Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 14));
        return e;
    }

    private View bottomBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Ui.BG);
        bar.setPadding(dp(20), dp(12), dp(20), dp(14));
        if (step > 0) {
            TextView back = Ui.button(this, t("b.back"), false);
            back.setOnClickListener(new Act() {
                void run() {
                    if (s.building) return;
                    s.error = null;
                    step--;
                    render(false);
                }
            });
            bar.addView(back, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 0, 10, 0));
        }
        String label = step < STEPS - 1 ? t("b.next") : (s.building ? t("b.busy") : t("b.build"));
        TextView next = Ui.button(this, label, true);
        if (s.building) next.setAlpha(0.5f);
        next.setOnClickListener(new Act() { void run() { onNext(); } });
        bar.addView(next, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        return bar;
    }

    // ----------------------------------------------------------- navigation

    private void fail(String msg) {
        s.error = msg;
        render(false);
    }

    private void onNext() {
        if (s.building) return;
        if (step == 0) {
            if (s.source == null) { fail(t("e.nosrc")); return; }
            if (s.scanning) return;
            if (!s.hasIndex && s.entryHtml == null) { fail(t("e.noidx")); return; }
        } else if (step == 1) {
            String key = ApkBuilder.validate(currentConfig(), getPackageName());
            if (key != null) { fail(t(key)); return; }
        } else if (step == 3) {
            s.error = null;
            startBuild();
            return;
        }
        s.error = null;
        step++;
        render(false);
    }

    // -------------------------------------------------------------- step 1

    private View optionCard(String title, String desc, boolean selected, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(16), dp(16), dp(16));
        row.setBackground(Ui.ripple(this, Ui.box(this, Ui.SURFACE, selected ? Ui.TEXT : Ui.LINE, 12), 0x22FFFFFF, 12));
        row.setClickable(true);
        row.setOnClickListener(click);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.text(this, title, 16, Ui.TEXT, true, false));
        col.addView(Ui.text(this, desc, 13, Ui.MUTED, false, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 5, 0, 0));
        row.addView(col, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));

        View dot = new View(this);
        dot.setBackground(selected ? Ui.oval(this, Ui.TEXT, Ui.TEXT, 1) : Ui.oval(this, 0, Ui.LINE, 2));
        row.addView(dot, Ui.lp(this, dp(20), dp(20), 14, 0, 0, 0));
        row.setLayoutParams(Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
        return row;
    }

    private View kv(String k, String v, int color) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, dp(6), 0, dp(6));
        TextView kt = Ui.text(this, k, 13, Ui.MUTED, false, false);
        r.addView(kt, Ui.lp(this, dp(104), Ui.WRAP, 0, 0, 0, 0));
        TextView vt = Ui.text(this, v, 13, color, false, true);
        r.addView(vt, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        return r;
    }

    private void stepSource(LinearLayout body) {
        body.addView(optionCard(t("s0.file.t"), t("s0.file.d"), s.source != null && !s.isDir, new Act() { void run() { pickHtml(); } }));
        body.addView(optionCard(t("s0.dir.t"), t("s0.dir.d"), s.source != null && s.isDir, new Act() { void run() { pickDir(); } }));
        if (s.source == null) return;

        LinearLayout c = Ui.card(this);
        c.addView(kv(t("i.name"), s.srcName, Ui.TEXT));
        if (s.scanning) {
            c.addView(kv(t("i.files"), t("i.scan"), Ui.MUTED));
        } else {
            c.addView(kv(t("i.files"), String.valueOf(s.fileCount), Ui.TEXT));
            c.addView(kv(t("i.size"), sizeStr(s.bytes), Ui.TEXT));
            if (s.hasIndex) c.addView(kv(t("i.start"), t("i.idx.ok"), Ui.GOOD));
            else if (s.entryHtml != null) c.addView(kv(t("i.start"), I18n.f("i.idx.alt", s.entryHtml), Ui.MUTED));
            else c.addView(kv(t("i.start"), t("i.none"), Ui.BAD));
            if (s.bytes > BIG) {
                TextView w = Ui.text(this, t("i.big"), 12, Ui.BAD, false, false);
                c.addView(w, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 8, 0, 0));
            }
        }
        body.addView(c);
    }

    // -------------------------------------------------------------- step 2

    private TextView label(String text) {
        TextView l = Ui.text(this, text, 12, Ui.MUTED, true, false);
        l.setLayoutParams(Ui.lp(this, Ui.WRAP, Ui.WRAP, 2, 16, 0, 7));
        return l;
    }

    private TextView help(String text) {
        TextView h = Ui.text(this, text, 12, Ui.DIM, false, false);
        h.setLayoutParams(Ui.lp(this, Ui.WRAP, Ui.WRAP, 2, 6, 0, 0));
        return h;
    }

    private void stepApp(LinearLayout body) {
        body.addView(label(t("f.name")));
        EditText name = Ui.field(this, t("f.name.h"), s.name, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS, false, false);
        name.addTextChangedListener(new Watch() {
            void changed(String x) {
                s.name = x;
                if (!s.pkgTouched) {
                    s.pkg = suggestPkg(x);
                    if (etPkg != null) {
                        settingPkg = true;
                        etPkg.setText(s.pkg);
                        settingPkg = false;
                    }
                }
            }
        });
        body.addView(name);

        body.addView(label(t("f.pkg")));
        etPkg = Ui.field(this, "com.namaku.aplikasi", s.pkg, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, true, false);
        etPkg.addTextChangedListener(new Watch() {
            void changed(String x) {
                s.pkg = x.trim();
                if (!settingPkg) s.pkgTouched = true;
            }
        });
        body.addView(etPkg);
        body.addView(help(t("f.pkg.d")));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(label(t("f.ver")));
        EditText ver = Ui.field(this, "1.0.0", s.verName, InputType.TYPE_CLASS_TEXT, true, false);
        ver.addTextChangedListener(new Watch() { void changed(String x) { s.verName = x.trim(); } });
        left.addView(ver);
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.addView(label(t("f.code")));
        right.addView(stepper());
        row.addView(left, Ui.weight(this, 1f, 0, 0, 6, 0));
        row.addView(right, Ui.weight(this, 1f, 6, 0, 0, 0));
        body.addView(row);

        body.addView(label(t("f.icon")));
        LinearLayout ic = new LinearLayout(this);
        ic.setOrientation(LinearLayout.HORIZONTAL);
        ic.setGravity(Gravity.CENTER_VERTICAL);
        if (s.iconThumb != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(s.iconThumb);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(Ui.box(this, Ui.RAISED, Ui.LINE, 12));
            iv.setPadding(1, 1, 1, 1);
            ic.addView(iv, Ui.lp(this, dp(56), dp(56), 0, 0, 14, 0));
        } else {
            TextView ph = Ui.text(this, "</>", 14, Ui.MUTED, true, true);
            ph.setGravity(Gravity.CENTER);
            ph.setBackground(Ui.box(this, Ui.RAISED, Ui.LINE, 12));
            ic.addView(ph, Ui.lp(this, dp(56), dp(56), 0, 0, 14, 0));
        }
        TextView pick = Ui.smallButton(this, t("f.icon.pick"));
        pick.setOnClickListener(new Act() { void run() { pickIcon(); } });
        ic.addView(pick, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        if (s.iconPng != null) {
            TextView reset = Ui.smallButton(this, t("f.icon.reset"));
            reset.setOnClickListener(new Act() {
                void run() {
                    s.iconPng = null;
                    s.iconThumb = null;
                    render(true);
                }
            });
            ic.addView(reset);
        }
        body.addView(ic);

        body.addView(label(t("f.lic")));
        EditText lic = Ui.field(this, t("f.lic.h"), s.license, InputType.TYPE_CLASS_TEXT, false, true);
        lic.addTextChangedListener(new Watch() { void changed(String x) { s.license = x; } });
        body.addView(lic);
        body.addView(help(t("f.lic.d")));
    }

    private View stepper() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(Ui.box(this, Ui.SURFACE, Ui.LINE, 10));

        final EditText et = new EditText(this);
        et.setText(String.valueOf(s.verCode));
        et.setTextColor(Ui.TEXT);
        et.setTextSize(15);
        et.setTypeface(android.graphics.Typeface.MONOSPACE);
        et.setIncludeFontPadding(false);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setSingleLine(true);
        et.setGravity(Gravity.CENTER);
        et.setBackground(null);
        et.setPadding(0, dp(13), 0, dp(13));
        et.addTextChangedListener(new Watch() {
            void changed(String x) {
                try { s.verCode = Integer.parseInt(x.trim()); } catch (NumberFormatException e) { s.verCode = 0; }
            }
        });

        TextView minus = Ui.text(this, "\u2212", 20, Ui.TEXT, false, false);
        minus.setGravity(Gravity.CENTER);
        minus.setOnClickListener(new Act() {
            void run() {
                int v = Math.max(1, s.verCode - 1);
                et.setText(String.valueOf(v));
            }
        });
        TextView plus = Ui.text(this, "+", 20, Ui.TEXT, false, false);
        plus.setGravity(Gravity.CENTER);
        plus.setOnClickListener(new Act() {
            void run() {
                int v = Math.max(0, s.verCode) + 1;
                et.setText(String.valueOf(v));
            }
        });
        box.addView(minus, Ui.lp(dp(40), Ui.MATCH));
        box.addView(et, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        box.addView(plus, Ui.lp(dp(40), Ui.MATCH));
        return box;
    }

    // -------------------------------------------------------------- step 3

    private View toggleRow(String title, String desc, boolean on, ToggleView.OnChange cb) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(13), 0, dp(13));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.text(this, title, 15, Ui.TEXT, true, false));
        col.addView(Ui.text(this, desc, 12, Ui.MUTED, false, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 4, 0, 0));
        r.addView(col, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        r.addView(new ToggleView(this, on, cb), Ui.lp(this, Ui.WRAP, Ui.WRAP, 14, 0, 0, 0));
        return r;
    }

    private void stepOptions(LinearLayout body) {
        LinearLayout c = Ui.card(this);
        c.setPadding(dp(16), dp(6), dp(16), dp(6));

        // orientasi
        LinearLayout o = new LinearLayout(this);
        o.setOrientation(LinearLayout.VERTICAL);
        o.setPadding(0, dp(13), 0, dp(14));
        o.addView(Ui.text(this, t("o.orient"), 15, Ui.TEXT, true, false));
        final TextView[] items = new TextView[3];
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.setBackground(Ui.box(this, Ui.RAISED, Ui.LINE, 9));
        seg.setPadding(dp(2), dp(2), dp(2), dp(2));
        String[] names = {t("o.auto"), t("o.port"), t("o.land")};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView tv = Ui.text(this, names[i], 13, Ui.MUTED, true, false);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, dp(9), 0, dp(9));
            tv.setOnClickListener(new Act() {
                void run() {
                    s.orientation = idx;
                    styleSegment(items, idx, 7);
                }
            });
            items[i] = tv;
            seg.addView(tv, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        }
        styleSegment(items, s.orientation, 7);
        o.addView(seg, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        c.addView(o);
        c.addView(Ui.hline(this));

        c.addView(toggleRow(t("o.full"), t("o.full.d"), s.fullscreen, new ToggleView.OnChange() { public void changed(boolean on) { s.fullscreen = on; } }));
        c.addView(Ui.hline(this));
        c.addView(toggleRow(t("o.keep"), t("o.keep.d"), s.keepOn, new ToggleView.OnChange() { public void changed(boolean on) { s.keepOn = on; } }));
        c.addView(Ui.hline(this));
        c.addView(toggleRow(t("o.zoom"), t("o.zoom.d"), s.zoom, new ToggleView.OnChange() { public void changed(boolean on) { s.zoom = on; } }));
        c.addView(Ui.hline(this));
        c.addView(toggleRow(t("o.off"), t("o.off.d"), s.offline, new ToggleView.OnChange() { public void changed(boolean on) { s.offline = on; } }));
        c.addView(Ui.hline(this));
        c.addView(toggleRow(t("o.ext"), t("o.ext.d"), s.ext, new ToggleView.OnChange() { public void changed(boolean on) { s.ext = on; } }));
        body.addView(c, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        LinearLayout col = Ui.card(this);
        col.addView(Ui.text(this, t("o.color"), 15, Ui.TEXT, true, false));
        col.addView(Ui.text(this, t("o.color.d"), 12, Ui.MUTED, false, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 4, 0, 14));
        LinearLayout sw = new LinearLayout(this);
        sw.setOrientation(LinearLayout.HORIZONTAL);
        final View[] dots = new View[SWATCH.length];
        for (int i = 0; i < SWATCH.length; i++) {
            final int idx = i;
            View d = new View(this);
            d.setOnClickListener(new Act() {
                void run() {
                    s.colorIdx = idx;
                    styleSwatches(dots);
                }
            });
            dots[i] = d;
            sw.addView(d, Ui.lp(this, dp(38), dp(38), 0, 0, 12, 0));
        }
        styleSwatches(dots);
        col.addView(sw);
        body.addView(col);
    }

    private void styleSwatches(View[] dots) {
        for (int i = 0; i < dots.length; i++) {
            boolean on = i == s.colorIdx;
            dots[i].setBackground(Ui.oval(this, SWATCH[i], on ? Ui.TEXT : Ui.LINE, on ? 2 : 1));
        }
    }

    // -------------------------------------------------------------- step 4

    private String optionsSummary() {
        List<String> p = new ArrayList<String>();
        if (s.orientation == 1) p.add(t("o.port"));
        if (s.orientation == 2) p.add(t("o.land"));
        if (s.fullscreen) p.add(t("o.full"));
        if (s.keepOn) p.add(t("o.keep"));
        if (s.zoom) p.add(t("o.zoom"));
        if (s.offline) p.add(t("o.off"));
        if (!s.ext) p.add(t("o.ext") + ": " + (I18n.en ? "off" : "mati"));
        if (p.isEmpty()) return t("r.defaults");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < p.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(p.get(i));
        }
        return sb.toString();
    }

    private void stepReview(LinearLayout body) {
        LinearLayout c = Ui.card(this);
        c.addView(kv(t("r.source"), s.srcName, Ui.TEXT));
        c.addView(kv(t("r.name"), s.name.trim(), Ui.TEXT));
        c.addView(kv(t("r.pkg"), s.pkg, Ui.TEXT));
        c.addView(kv(t("r.ver"), s.verName + " (" + s.verCode + ")", Ui.TEXT));
        c.addView(kv(t("r.icon"), s.iconPng != null ? t("r.icon.custom") : t("r.icon.def"), Ui.TEXT));
        c.addView(kv(t("r.opts"), optionsSummary(), Ui.TEXT));
        body.addView(c, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));

        if (s.building || s.done || s.progress > 0) body.addView(progressCard());
        if (s.done && s.outUri != null) body.addView(resultCard());

        LinearLayout k = Ui.card(this);
        k.addView(Ui.text(this, t("k.title"), 15, Ui.TEXT, true, false));
        k.addView(Ui.text(this, t("k.d"), 12, Ui.MUTED, false, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 6, 0, 12));
        if (KeyStoreManager.exists(getFilesDir())) {
            if (s.fingerprint != null) k.addView(kv(t("k.fp"), s.fingerprint, Ui.TEXT));
            else loadFingerprint();
        } else {
            k.addView(Ui.text(this, t("k.new"), 12, Ui.DIM, false, false));
        }
        TextView backup = Ui.smallButton(this, t("k.backup"));
        backup.setOnClickListener(new Act() { void run() { pickBackup(); } });
        k.addView(backup, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 12, 0, 0));
        body.addView(k);
    }

    private View progressCard() {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, t("p.title"), 12, Ui.MUTED, true, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 0, 0, 8));
        String[] keys = {"p.read", "p.key", "p.pack", "p.sign", "p.save"};
        for (int i = 0; i < keys.length; i++) {
            boolean done = i < s.progress;
            boolean active = i == s.progress && s.building;
            String mark = done ? "ok " : (active ? ".. " : "   ");
            int col = done ? Ui.GOOD : (active ? Ui.TEXT : Ui.DIM);
            TextView line = Ui.text(this, String.format(Locale.ROOT, "%02d  %s", i + 1, t(keys[i])), 13, col, false, true);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, dp(4), 0, dp(4));
            row.addView(line, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
            row.addView(Ui.text(this, mark.trim(), 13, col, false, true));
            c.addView(row);
        }
        c.setLayoutParams(Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
        return c;
    }

    private View resultCard() {
        LinearLayout c = Ui.card(this);
        c.setBackground(Ui.box(this, Ui.SURFACE, Ui.GOOD, 12));
        c.addView(Ui.text(this, t("res.title"), 16, Ui.TEXT, true, false));
        c.addView(Ui.text(this, I18n.f("res.path", s.outName), 12, Ui.MUTED, false, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 8, 0, 0));
        c.addView(Ui.text(this, t("res.hint"), 12, Ui.DIM, false, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 8, 0, 14));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView share = Ui.smallButton(this, t("res.share"));
        share.setOnClickListener(new Act() { void run() { shareApk(); } });
        TextView open = Ui.smallButton(this, t("res.open"));
        open.setOnClickListener(new Act() { void run() { openDownloads(); } });
        row.addView(share, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        row.addView(open);
        c.addView(row);
        c.setLayoutParams(Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 12));
        return c;
    }

    private void loadFingerprint() {
        if (s.fpLoading) return;
        s.fpLoading = true;
        new Thread(new Runnable() {
            public void run() {
                try {
                    s.fingerprint = KeyStoreManager.loadOrCreate(getFilesDir()).fingerprint();
                    renderUi(true);
                } catch (Throwable ignored) {
                    s.fpLoading = false;
                }
            }
        }).start();
    }

    // ------------------------------------------------------------- pickers

    private void pickHtml() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/html", "application/xhtml+xml", "application/octet-stream", "text/plain"});
        startActivityForResult(i, REQ_HTML);
    }

    private void pickDir() {
        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_DIR);
    }

    private void pickIcon() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, REQ_ICON);
    }

    private void pickBackup() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/x-pkcs12");
        i.putExtra(Intent.EXTRA_TITLE, "html2apk-key.p12");
        startActivityForResult(i, REQ_BACKUP);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri u = data.getData();
        s.error = null;
        if (req == REQ_HTML) {
            String n = displayName(u);
            if (n == null || !n.toLowerCase(Locale.ROOT).matches(".*\\.(html|htm)$")) {
                fail(t("e.html"));
                return;
            }
            s.source = u;
            s.isDir = false;
            s.srcName = n;
            s.entryHtml = n;
            s.hasIndex = true;
            s.scanning = false;
            s.fileCount = 1;
            s.bytes = querySize(u);
            autoFill(n.replaceAll("\\.[^.]+$", ""));
            render(false);
        } else if (req == REQ_DIR) {
            s.source = u;
            s.isDir = true;
            String id = DocumentsContract.getTreeDocumentId(u);
            String n = id.contains(":") ? id.substring(id.lastIndexOf(':') + 1) : id;
            if (n.contains("/")) n = n.substring(n.lastIndexOf('/') + 1);
            if (n.isEmpty()) n = "Project";
            s.srcName = n;
            s.scanning = true;
            s.entryHtml = null;
            s.hasIndex = false;
            autoFill(n);
            render(false);
            new Thread(new Runnable() {
                public void run() {
                    try {
                        Scan sc = scan(u, true);
                        s.fileCount = sc.files.size();
                        s.bytes = sc.bytes;
                        s.hasIndex = sc.hasIndex;
                        s.entryHtml = sc.topHtml;
                        s.scanning = false;
                        s.error = null;
                    } catch (Throwable e) {
                        s.scanning = false;
                        s.source = null;
                        s.error = e instanceof IOException && e.getMessage() != null ? e.getMessage() : t("e.scan");
                    }
                    renderUi(true);
                }
            }).start();
        } else if (req == REQ_ICON) {
            try {
                byte[] png = makeIcon(u);
                s.iconPng = png;
                s.iconThumb = BitmapFactory.decodeByteArray(png, 0, png.length);
                render(true);
            } catch (IOException e) {
                fail(t("e.icon"));
            }
        } else if (req == REQ_BACKUP) {
            doBackup(u);
        }
    }

    private void autoFill(String base) {
        if (!s.name.trim().isEmpty()) return;
        String nm = base.replaceAll("[-_]+", " ").trim();
        if (!nm.isEmpty()) nm = Character.toUpperCase(nm.charAt(0)) + nm.substring(1);
        s.name = nm;
        if (!s.pkgTouched) s.pkg = suggestPkg(nm);
    }

    private static String suggestPkg(String name) {
        String x = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (x.isEmpty()) return "";
        if (Character.isDigit(x.charAt(0))) x = "app" + x;
        return "com.app." + x;
    }

    private String displayName(Uri u) {
        Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
        try {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    private long querySize(Uri u) {
        Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.SIZE}, null, null, null);
        try {
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getLong(0);
        } finally {
            if (c != null) c.close();
        }
        return 0;
    }

    private static String sizeStr(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024) return String.format(Locale.ROOT, "%.1f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format(Locale.ROOT, "%.1f MB", b / 1048576.0);
        return String.format(Locale.ROOT, "%.2f GB", b / 1073741824.0);
    }

    // ---------------------------------------------------------- source scan

    private static final class Scan {
        final List<UriAsset> files = new ArrayList<UriAsset>();
        String topHtml;
        Uri topHtmlUri;
        long bytes;
        boolean hasIndex;
    }

    private Scan scan(Uri src, boolean dir) throws IOException {
        Scan sc = new Scan();
        if (!dir) {
            long size = querySize(src);
            sc.files.add(new UriAsset("index.html", src, size));
            sc.bytes = size;
            sc.hasIndex = true;
            sc.topHtml = displayName(src);
            sc.topHtmlUri = src;
            return sc;
        }
        walk(src, DocumentsContract.getTreeDocumentId(src), "", sc, 0);
        return sc;
    }

    private void walk(Uri tree, String docId, String prefix, Scan sc, int depth) throws IOException {
        if (depth > 12) return;
        Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        Cursor c = getContentResolver().query(kids, new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE}, null, null, null);
        if (c == null) throw new IOException(t("e.scan"));
        try {
            while (c.moveToNext()) {
                String id = c.getString(0), name = c.getString(1), mime = c.getString(2);
                long size = c.isNull(3) ? 0 : c.getLong(3);
                if (name == null || name.startsWith(".") || name.equals("node_modules")) continue;
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    walk(tree, id, prefix + name + "/", sc, depth + 1);
                } else {
                    if (sc.files.size() >= MAX_FILES) throw new IOException(t("e.many"));
                    Uri fu = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                    String path = prefix + name;
                    sc.files.add(new UriAsset(path, fu, size));
                    sc.bytes += size;
                    if (path.equals("index.html")) sc.hasIndex = true;
                    String ln = name.toLowerCase(Locale.ROOT);
                    if (prefix.isEmpty() && sc.topHtmlUri == null && (ln.endsWith(".html") || ln.endsWith(".htm"))) {
                        sc.topHtml = name;
                        sc.topHtmlUri = fu;
                    }
                }
            }
        } finally {
            c.close();
        }
    }

    private class UriAsset implements ApkBuilder.Asset {
        private final String path;
        private final Uri uri;
        final long size;

        UriAsset(String path, Uri uri, long size) {
            this.path = path;
            this.uri = uri;
            this.size = size;
        }

        public String path() { return path; }

        public byte[] read() throws IOException {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new IOException("Cannot open " + path);
            return ApkBuilder.readAll(in);
        }
    }

    // --------------------------------------------------------------- build

    private ApkBuilder.Config currentConfig() {
        ApkBuilder.Config c = new ApkBuilder.Config();
        c.appName = s.name.trim();
        c.pkg = s.pkg.trim();
        c.versionName = s.verName.trim();
        c.versionCode = s.verCode;
        c.license = s.license;
        c.iconPng = s.iconPng;
        c.extraConfig = configProps();
        return c;
    }

    private String configProps() {
        String o = s.orientation == 1 ? "portrait" : (s.orientation == 2 ? "landscape" : "auto");
        return "orientation=" + o + "\n"
                + "fullscreen=" + s.fullscreen + "\n"
                + "keepOn=" + s.keepOn + "\n"
                + "zoom=" + s.zoom + "\n"
                + "offline=" + s.offline + "\n"
                + "externalBrowser=" + s.ext + "\n"
                + String.format(Locale.ROOT, "color=#%06X\n", SWATCH[s.colorIdx] & 0xFFFFFF);
    }

    private void startBuild() {
        final ApkBuilder.Config c = currentConfig();
        String key = ApkBuilder.validate(c, getPackageName());
        if (key != null) {
            fail(t(key));
            return;
        }
        s.building = true;
        s.done = false;
        s.progress = 0;
        s.outUri = null;
        render(true);
        final Uri src = s.source;
        final boolean dir = s.isDir;
        new Thread(new Runnable() {
            public void run() {
                try {
                    Scan sc = scan(src, dir);
                    List<ApkBuilder.Asset> www = new ArrayList<ApkBuilder.Asset>(sc.files);
                    if (!sc.hasIndex) {
                        if (sc.topHtmlUri == null) throw new IOException(t("e.noidx"));
                        www.add(new UriAsset("index.html", sc.topHtmlUri, 0));
                    }
                    progress(1);

                    KeyStoreManager km = KeyStoreManager.loadOrCreate(getFilesDir());
                    s.fingerprint = km.fingerprint();
                    progress(2);

                    File tpl = new File(getCacheDir(), "template.apk");
                    copy(getAssets().open("template.apk"), new FileOutputStream(tpl));
                    File unsigned = new File(getCacheDir(), "unsigned.apk");
                    File signed = new File(getCacheDir(), "signed.apk");
                    signed.delete();
                    ApkBuilder.buildUnsigned(tpl, www, c, unsigned);
                    progress(3);

                    ApkSign.sign(unsigned, signed, km);
                    unsigned.delete();
                    progress(4);

                    String fileName = slug(c.appName) + "-" + slug(c.versionName) + ".apk";
                    Uri out = saveToDownloads(signed, fileName);
                    signed.delete();
                    s.outUri = out;
                    s.outName = fileName;
                    s.building = false;
                    s.done = true;
                    s.progress = 5;
                    renderUi(true);
                } catch (Throwable e) {
                    s.building = false;
                    s.done = false;
                    s.progress = 0;
                    String m = e.getMessage() != null ? e.getMessage() : e.toString();
                    s.error = I18n.f("e.fail", m);
                    renderUi(false);
                }
            }
        }).start();
    }

    private void progress(int p) {
        s.progress = p;
        renderUi(true);
    }

    private byte[] makeIcon(Uri u) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in1 = getContentResolver().openInputStream(u);
        try { BitmapFactory.decodeStream(in1, null, o); } finally { if (in1 != null) in1.close(); }
        int side = Math.max(1, Math.min(o.outWidth, o.outHeight));
        o.inJustDecodeBounds = false;
        o.inSampleSize = Math.max(1, side / 512);
        InputStream in2 = getContentResolver().openInputStream(u);
        Bitmap src;
        try { src = BitmapFactory.decodeStream(in2, null, o); } finally { if (in2 != null) in2.close(); }
        if (src == null) throw new IOException("bad image");
        int sz = Math.min(src.getWidth(), src.getHeight());
        Bitmap sq = Bitmap.createBitmap(src, (src.getWidth() - sz) / 2, (src.getHeight() - sz) / 2, sz, sz);
        Bitmap icon = Bitmap.createScaledBitmap(sq, 192, 192, true);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        icon.compress(Bitmap.CompressFormat.PNG, 100, bo);
        return bo.toByteArray();
    }

    private Uri saveToDownloads(File f, String name) throws IOException {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive");
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Html2Apk");
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new IOException("Cannot create file in Downloads");
        copy(new FileInputStream(f), getContentResolver().openOutputStream(u));
        return u;
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        try {
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            in.close();
            if (out != null) out.close();
        }
    }

    private static String slug(String x) {
        String r = x.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9.]+", "-").replaceAll("^-+|-+$", "");
        return r.isEmpty() ? "app" : r;
    }

    // ------------------------------------------------- share, open, backup

    private void shareApk() {
        if (s.outUri == null) return;
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/vnd.android.package-archive");
            i.putExtra(Intent.EXTRA_STREAM, s.outUri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, null));
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void openDownloads() {
        try {
            startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
        } catch (Exception e) {
            Toast.makeText(this, "Download/Html2Apk", Toast.LENGTH_LONG).show();
        }
    }

    private void doBackup(final Uri target) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    final KeyStoreManager km = KeyStoreManager.loadOrCreate(getFilesDir());
                    copy(new FileInputStream(km.p12File), getContentResolver().openOutputStream(target));
                    runOnUiThread(new Runnable() {
                        public void run() {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle(t("k.done.t"))
                                    .setMessage(t("k.done.m") + "\n\n" + km.password)
                                    .setPositiveButton(t("ok"), null)
                                    .show();
                        }
                    });
                } catch (Throwable e) {
                    s.error = I18n.f("e.fail", String.valueOf(e.getMessage()));
                    renderUi(true);
                }
            }
        }).start();
    }
}
