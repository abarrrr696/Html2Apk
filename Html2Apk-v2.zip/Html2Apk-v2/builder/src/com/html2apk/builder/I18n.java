package com.html2apk.builder;

import java.util.HashMap;
import java.util.Map;

/** Teks antarmuka dua bahasa: Indonesia (id) dan Inggris (en). */
final class I18n {
    static boolean en = false;
    private static final Map<String, String[]> T = new HashMap<String, String[]>();

    private I18n() {}

    static String t(String key) {
        String[] v = T.get(key);
        if (v == null) return key;
        return en ? v[1] : v[0];
    }

    static String f(String key, Object... args) {
        return String.format(t(key), args);
    }

    static boolean has(String key) { return T.containsKey(key); }
    static java.util.Set<String> keys() { return T.keySet(); }

    private static void p(String k, String id, String enText) { T.put(k, new String[]{id, enText}); }

    static {
        // langkah 1: sumber
        p("s0.title", "Pilih sumber", "Choose a source");
        p("s0.sub", "Satu file HTML, atau satu folder berisi semua file situsmu.", "One HTML file, or one folder with all your site files.");
        p("s0.file.t", "File HTML", "HTML file");
        p("s0.file.d", "Satu file saja. CSS dan JS boleh ditulis di dalamnya.", "A single file. CSS and JS can live inside it.");
        p("s0.dir.t", "Folder proyek", "Project folder");
        p("s0.dir.d", "HTML, CSS, JS, gambar, dan musik dalam satu folder.", "HTML, CSS, JS, images and audio in one folder.");
        p("i.name", "Nama", "Name");
        p("i.files", "Jumlah file", "Files");
        p("i.size", "Ukuran", "Size");
        p("i.start", "Halaman awal", "Start page");
        p("i.scan", "Memeriksa folder...", "Checking folder...");
        p("i.idx.ok", "index.html", "index.html");
        p("i.idx.alt", "%s (tidak ada index.html)", "%s (no index.html)");
        p("i.none", "Tidak ada file .html", "No .html file");
        p("i.big", "Proyek besar. Proses bisa lambat atau gagal.", "Large project. Building may be slow or fail.");
        // langkah 2: data
        p("s1.title", "Data aplikasi", "App details");
        p("s1.sub", "Yang tampil di layar HP dan di daftar aplikasi.", "What shows on the phone and in the app list.");
        p("f.name", "Nama aplikasi", "App name");
        p("f.name.h", "Contoh: Toko Saya", "Example: My Shop");
        p("f.pkg", "Nama paket", "Package name");
        p("f.pkg.d", "ID unik aplikasi. Huruf kecil, angka, dan titik.", "Unique app ID. Lowercase letters, digits and dots.");
        p("f.ver", "Versi", "Version");
        p("f.code", "Kode versi", "Version code");
        p("f.icon", "Ikon", "Icon");
        p("f.icon.pick", "Pilih gambar", "Choose image");
        p("f.icon.reset", "Pakai bawaan", "Use default");
        p("f.lic", "Lisensi atau hak cipta", "License or copyright");
        p("f.lic.d", "Opsional. Disimpan di dalam aplikasi sebagai LICENSE.txt.", "Optional. Saved inside the app as LICENSE.txt.");
        p("f.lic.h", "(c) 2026 Namamu. MIT License", "(c) 2026 Your Name. MIT License");
        // langkah 3: opsi
        p("s2.title", "Perilaku aplikasi", "App behavior");
        p("s2.sub", "Semua opsional. Bawaannya sudah cocok untuk kebanyakan situs.", "All optional. The defaults suit most sites.");
        p("o.orient", "Orientasi layar", "Screen orientation");
        p("o.auto", "Otomatis", "Auto");
        p("o.port", "Tegak", "Portrait");
        p("o.land", "Mendatar", "Landscape");
        p("o.full", "Layar penuh", "Fullscreen");
        p("o.full.d", "Sembunyikan bilah status dan navigasi.", "Hide the status and navigation bars.");
        p("o.keep", "Layar tetap menyala", "Keep screen on");
        p("o.keep.d", "Cocok untuk game, jam, atau pemutar.", "Good for games, clocks and players.");
        p("o.zoom", "Zoom dengan dua jari", "Pinch to zoom");
        p("o.zoom.d", "Izinkan halaman diperbesar.", "Let people zoom the page.");
        p("o.off", "Hanya offline", "Offline only");
        p("o.off.d", "Blokir semua permintaan internet dari halaman.", "Block every internet request from the page.");
        p("o.ext", "Tautan luar buka di browser", "Open outside links in browser");
        p("o.ext.d", "Jika mati, tautan dibuka di dalam aplikasi.", "If off, links open inside the app.");
        p("o.color", "Warna aplikasi", "App color");
        p("o.color.d", "Untuk bilah status dan latar sebelum halaman tampil.", "For the status bar and the background before the page shows.");
        // langkah 4: periksa
        p("s3.title", "Periksa dan buat", "Review and build");
        p("s3.sub", "Pastikan datanya benar, lalu tekan Buat APK.", "Check the details, then press Build APK.");
        p("r.source", "Sumber", "Source");
        p("r.name", "Nama", "Name");
        p("r.pkg", "Paket", "Package");
        p("r.ver", "Versi", "Version");
        p("r.icon", "Ikon", "Icon");
        p("r.icon.custom", "Gambar sendiri", "Custom image");
        p("r.icon.def", "Bawaan", "Default");
        p("r.opts", "Opsi", "Options");
        p("r.defaults", "Bawaan", "Defaults");
        p("k.title", "Key penanda tangan", "Signing key");
        p("k.d", "Semua APK memakai satu key (RSA 3072). Simpan cadangannya agar aplikasimu bisa di-update.", "Every APK uses one key (RSA 3072). Back it up so your apps can be updated.");
        p("k.new", "Key dibuat otomatis saat build pertama.", "The key is created on the first build.");
        p("k.fp", "Sidik jari", "Fingerprint");
        p("k.backup", "Cadangkan key", "Back up key");
        p("k.done.t", "Cadangan tersimpan", "Backup saved");
        p("k.done.m", "Catat password ini dan simpan terpisah dari file-nya:", "Write this password down and keep it apart from the file:");
        p("ok", "Mengerti", "Got it");
        // navigasi
        p("b.back", "Kembali", "Back");
        p("b.next", "Lanjut", "Next");
        p("b.build", "Buat APK", "Build APK");
        p("b.busy", "Sedang membuat...", "Building...");
        // proses
        p("p.title", "Proses", "Progress");
        p("p.read", "Membaca file", "Reading files");
        p("p.key", "Menyiapkan key", "Preparing key");
        p("p.pack", "Merakit APK", "Assembling APK");
        p("p.sign", "Menandatangani", "Signing");
        p("p.save", "Menyimpan", "Saving");
        // hasil
        p("res.title", "APK siap", "APK ready");
        p("res.path", "Download/Html2Apk/%s", "Download/Html2Apk/%s");
        p("res.share", "Bagikan APK", "Share APK");
        p("res.open", "Buka folder Download", "Open Downloads");
        p("res.hint", "Buka lewat aplikasi File untuk memasang. Android akan meminta izin pasang dari sumber tersebut.", "Open it from the Files app to install. Android will ask you to allow installs from that source.");
        // galat
        p("e.nosrc", "Pilih file HTML atau folder dulu.", "Pick an HTML file or a folder first.");
        p("e.html", "File harus berakhiran .html atau .htm.", "The file must end with .html or .htm.");
        p("e.noidx", "Folder tidak berisi file .html.", "The folder has no .html file.");
        p("e.many", "Terlalu banyak file (maks. 5000).", "Too many files (max 5000).");
        p("e.fail", "Gagal: %s", "Failed: %s");
        p("e.icon", "Gambar ikon tidak bisa dibaca.", "That icon image could not be read.");
        p("e.scan", "Folder tidak bisa dibaca.", "The folder could not be read.");
        p("v.name", "Nama aplikasi belum diisi.", "The app name is empty.");
        p("v.namelong", "Nama aplikasi terlalu panjang (maks. 60 huruf).", "The app name is too long (max 60 characters).");
        p("v.pkg", "Nama paket tidak valid. Contoh: com.namaku.toko (huruf kecil, angka, titik, minimal dua bagian).", "Invalid package name. Example: com.myname.shop (lowercase, digits, dots, at least two parts).");
        p("v.pkglen", "Nama paket terlalu panjang.", "The package name is too long.");
        p("v.pkgown", "Nama paket ini dipakai aplikasi pembuat. Pilih yang lain.", "This package name belongs to the builder app. Pick another.");
        p("v.ver", "Versi belum benar. Contoh: 1.0.0", "The version is not valid. Example: 1.0.0");
        p("v.code", "Kode versi harus angka 1 atau lebih.", "The version code must be 1 or more.");
    }
}
