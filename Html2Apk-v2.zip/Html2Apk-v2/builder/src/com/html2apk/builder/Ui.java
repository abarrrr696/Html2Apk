package com.html2apk.builder;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Warna, bentuk, dan komponen dasar. Satu palet abu-hitam, garis tipis, tanpa gradasi atau bayangan. */
final class Ui {
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    static final int BG = 0xFF0D0D0F;
    static final int SURFACE = 0xFF151518;
    static final int RAISED = 0xFF1E1E22;
    static final int LINE = 0xFF2B2B30;
    static final int TEXT = 0xFFE8E8EB;
    static final int MUTED = 0xFF8C8C94;
    static final int DIM = 0xFF5B5B63;
    static final int BAD = 0xFFE07A6E;
    static final int GOOD = 0xFF8FBF93;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable box(Context c, int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(Math.max(1, dp(c, 1)), stroke);
        return g;
    }

    static GradientDrawable oval(Context c, int fill, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        if (stroke != 0) g.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        return g;
    }

    static Drawable ripple(Context c, Drawable content, int rippleColor, float radiusDp) {
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(c, radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask);
    }

    static TextView text(Context c, CharSequence s, float sp, int color, boolean medium, boolean mono) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        t.setLineSpacing(0, 1.18f);
        t.setTypeface(mono ? Typeface.MONOSPACE : Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        return t;
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    /** Margin dalam dp. */
    static LinearLayout.LayoutParams lp(Context c, int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static LinearLayout.LayoutParams weight(Context c, float w, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, w);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    /** Tombol dari TextView: terisi terang (utama) atau berbingkai (sekunder). */
    static TextView button(Context c, String label, boolean primary) {
        TextView b = text(c, label, 15, primary ? BG : TEXT, true, false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(c, 18), dp(c, 15), dp(c, 18), dp(c, 15));
        b.setClickable(true);
        b.setBackground(ripple(c, primary ? box(c, TEXT, 0, 10) : box(c, SURFACE, LINE, 10),
                primary ? 0x33000000 : 0x22FFFFFF, 10));
        return b;
    }

    static TextView smallButton(Context c, String label) {
        TextView b = text(c, label, 13, TEXT, true, false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        b.setClickable(true);
        b.setBackground(ripple(c, box(c, SURFACE, LINE, 8), 0x22FFFFFF, 8));
        return b;
    }

    static EditText field(Context c, String hint, String value, int inputType, boolean mono, boolean multiline) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(DIM);
        e.setText(value);
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setIncludeFontPadding(false);
        e.setTypeface(mono ? Typeface.MONOSPACE : Typeface.create("sans-serif", Typeface.NORMAL));
        e.setInputType(multiline ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) : inputType);
        if (multiline) {
            e.setMinLines(3);
            e.setGravity(Gravity.TOP | Gravity.START);
        } else {
            e.setSingleLine(true);
        }
        e.setPadding(dp(c, 14), dp(c, 13), dp(c, 14), dp(c, 13));
        e.setBackground(box(c, SURFACE, LINE, 10));
        e.setHighlightColor(0x55FFFFFF);
        GradientDrawable cursor = new GradientDrawable();
        cursor.setColor(TEXT);
        cursor.setSize(dp(c, 2), dp(c, 20));
        e.setTextCursorDrawable(cursor);
        return e;
    }

    static View hline(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, Math.max(1, dp(c, 1))));
        return v;
    }

    /** Wadah kartu: permukaan sedikit lebih terang, garis tipis. */
    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(box(c, SURFACE, LINE, 12));
        l.setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16));
        return l;
    }
}
