# Html2Apk 2

Aplikasi Android (jalan langsung di HP) yang mengubah file HTML atau folder situs jadi APK.
Alur empat langkah: Sumber, Data aplikasi, Perilaku, Periksa dan buat. Bahasa Indonesia atau Inggris
(tombol ID/EN di pojok kanan atas). Tema abu-abu hitam.

## Opsi untuk pembuat aplikasi
Orientasi (otomatis, tegak, mendatar), layar penuh, layar tetap menyala, zoom dua jari,
hanya offline (blokir internet), tautan luar di browser atau di dalam aplikasi, warna aplikasi
(bilah status dan latar sebelum halaman tampil), ikon sendiri, lisensi, nama paket, versi.
Pengaturan ditulis ke `assets/config.properties` di dalam APK dan dibaca template saat aplikasi jalan.

## Membangun (Kali / NetHunter)
```
apt install -y unzip default-jdk aapt zipalign
cd ~/Html2Apk-v2
chmod +x build.sh tests.sh
./tests.sh      # uji bagian inti tanpa Android
./build.sh      # hasil: out/Html2Apk.apk
```
Key penanda tangan aplikasi pembuat ada di `~/.html2apk/builder.jks`. Memakai key yang sama dengan versi 1
berarti Html2Apk 2 akan menimpa (meng-update) Html2Apk 1 di HP.

## Catatan desain
- Tidak ada izin `REQUEST_INSTALL_PACKAGES`: pembuat tidak memasang APK sendiri. Hasil dibuka lewat aplikasi File,
  atau dibagikan lewat tombol Bagikan. Ini mengurangi ciri "dropper" yang sering memicu peringatan keamanan.
- `tools/StripMethodParameters.java` membersihkan class file dari javac 21 agar d8 lama tidak crash.
- Template melayani audio dan video dengan permintaan Range, jadi lagu bisa digeser. Belum diuji di perangkat.
