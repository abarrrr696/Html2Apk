package com.html2apk.builder;

import java.io.*;
import java.nio.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.zip.*;

public class CoreTest {
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); System.out.println("OK  " + msg); }

    public static void main(String[] a) throws Exception {
        testZip();
        testCert();
        testKeyStore();
        testAxml(false);
        testAxml(true);
        System.out.println("SEMUA TES LULUS");
    }

    static void testZip() throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ZipWriter z = new ZipWriter(bo);
        Random r = new Random(1);
        byte[] arsc = new byte[1000]; r.nextBytes(arsc);
        z.add("AndroidManifest.xml", "x".repeat(300).getBytes(), false);
        z.add("resources.arsc", arsc, true);
        z.add("a/b.txt", "hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello hello".getBytes(), false);
        z.add("odd", new byte[]{1,2,3}, true);
        z.add("res/x.png", new byte[]{9,9,9,9,9}, true);
        z.close();
        byte[] zip = bo.toByteArray();
        File f = File.createTempFile("tes", ".zip"); try (FileOutputStream o = new FileOutputStream(f)) { o.write(zip); }
        try (ZipFile zf = new ZipFile(f)) {
            check(zf.size() == 5, "ZIP terbaca, 5 entri");
            InputStream in = zf.getInputStream(zf.getEntry("resources.arsc"));
            check(Arrays.equals(in.readAllBytes(), arsc), "isi resources.arsc sama (crc valid)");
        }
        // cek alignment 4 byte tiap entri STORED lewat local header
        ByteBuffer b = ByteBuffer.wrap(zip).order(ByteOrder.LITTLE_ENDIAN);
        int p = 0, stored = 0;
        while (b.getInt(p) == 0x04034b50) {
            int method = b.getShort(p + 8), csize = b.getInt(p + 18), nl = b.getShort(p + 26), el = b.getShort(p + 28);
            int dataOff = p + 30 + nl + el;
            if (method == 0) { stored++; check(dataOff % 4 == 0, "STORED rata 4 byte @" + dataOff); }
            p = dataOff + csize;
        }
        check(stored == 3, "3 entri STORED");
        Process pr = new ProcessBuilder("unzip", "-tq", f.getPath()).redirectErrorStream(true).start();
        String out = new String(pr.getInputStream().readAllBytes()); pr.waitFor();
        check(out.contains("No errors"), "unzip -t: " + out.trim());
    }

    static void testCert() throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA"); g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        X509Certificate c = KeyStoreManager.selfSign(kp, "Tes", new SecureRandom());
        c.verify(kp.getPublic());
        c.checkValidity();
        check(c.getSubjectX500Principal().getName().contains("CN=Tes"), "sertifikat valid & ditandatangani: " + c.getSigAlgName());
        check(c.getNotAfter().getTime() > System.currentTimeMillis() + 29L * 365 * 86400000, "masa berlaku ~30 tahun: " + c.getNotAfter());
    }

    static void testKeyStore() throws Exception {
        File d = java.nio.file.Files.createTempDirectory("ks").toFile();
        KeyStoreManager k1 = KeyStoreManager.loadOrCreate(d);
        KeyStoreManager k2 = KeyStoreManager.loadOrCreate(d);
        check(Arrays.equals(k1.cert.getEncoded(), k2.cert.getEncoded()), "key dipakai ulang di pemuatan kedua");
        check(KeyStoreManager.exists(d) && k1.fingerprint().matches("([0-9A-F]{2}:){7}[0-9A-F]{2}"), "fingerprint: " + k1.fingerprint());
        Signature s = Signature.getInstance("SHA256withRSA"); s.initSign(k2.key); s.update(new byte[]{1}); byte[] sg = s.sign();
        s.initVerify(k2.cert); s.update(new byte[]{1});
        check(s.verify(sg), "key privat cocok dengan sertifikat (RSA 3072)");
    }

    // ---- AXML sintetis ----
    static byte[] buildAxml(boolean utf8) throws Exception {
        String[] ss = {"versionCode", "package", "label", "http://schemas.android.com/apk/res/android", "manifest",
                       "com.html2apk.placeholder", "__APP_NAME__", "0.0.0-placeholder", "versionName"};
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] off = new int[ss.length];
        for (int i = 0; i < ss.length; i++) {
            off[i] = data.size();
            if (utf8) { data.write(ss[i].length()); data.write(ss[i].length()); data.write(ss[i].getBytes("UTF-8")); data.write(0); }
            else { data.write(ss[i].length()); data.write(0); for (char ch : ss[i].toCharArray()) { data.write(ch); data.write(0); } data.write(0); data.write(0); }
        }
        while (data.size() % 4 != 0) data.write(0);
        int strStart = 28 + 4 * ss.length, poolSize = strStart + data.size();
        ByteBuffer pool = ByteBuffer.allocate(poolSize).order(ByteOrder.LITTLE_ENDIAN);
        pool.putShort((short) 1).putShort((short) 28).putInt(poolSize).putInt(ss.length).putInt(0).putInt(utf8 ? 0x100 : 0).putInt(strStart).putInt(0);
        for (int o : off) pool.putInt(o);
        pool.put(data.toByteArray());

        // start element <manifest package=.. android:versionCode=1 android:label=..>
        int nattr = 3, size = 36 + 20 * nattr;
        ByteBuffer el = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        el.putShort((short) 0x0102).putShort((short) 16).putInt(size).putInt(1).putInt(-1);
        el.putInt(-1).putInt(4).putShort((short) 20).putShort((short) 20).putShort((short) nattr).putShort((short) 0).putShort((short) 0).putShort((short) 0);
        // package
        el.putInt(-1).putInt(1).putInt(5).putShort((short) 8).put((byte) 0).put((byte) 3).putInt(5);
        // versionCode
        el.putInt(3).putInt(0).putInt(-1).putShort((short) 8).put((byte) 0).put((byte) 0x10).putInt(1);
        // label
        el.putInt(3).putInt(2).putInt(6).putShort((short) 8).put((byte) 0).put((byte) 3).putInt(6);
        ByteArrayOutputStream all = new ByteArrayOutputStream();
        ByteBuffer hdr = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
        hdr.putShort((short) 3).putShort((short) 8).putInt(8 + poolSize + size);
        all.write(hdr.array()); all.write(pool.array()); all.write(el.array());
        return all.toByteArray();
    }

    static void testAxml(boolean utf8) throws Exception {
        byte[] src = buildAxml(utf8);
        Map<String, String> m = new HashMap<>();
        m.put("com.html2apk.placeholder", "id.bagus.aplikasi_saya");
        m.put("__APP_NAME__", "Aplikasi Saya \u00e9\u4e2d");
        byte[] out = AxmlPatcher.patch(src, m, 4242);
        ByteBuffer b = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN);
        check(b.getInt(4) == out.length, (utf8 ? "UTF-8" : "UTF-16") + ": ukuran file di header cocok");
        int poolSize = b.getInt(12), cnt = b.getInt(16), ssz = b.getInt(28);
        check(poolSize % 4 == 0, "pool rata 4 byte");
        // baca ulang string, lalu atribut elemen
        List<String> got = new ArrayList<>();
        for (int i = 0; i < cnt; i++) {
            int o = 8 + ssz + b.getInt(8 + 28 + 4 * i);
            if (utf8) { int l1 = b.get(o++) & 0xFF; if ((l1&0x80)!=0) o++; int l2 = b.get(o++) & 0xFF; if ((l2&0x80)!=0){ l2=((l2&0x7F)<<8)|(b.get(o++)&0xFF);} byte[] x = new byte[l2]; for (int k=0;k<l2;k++) x[k]=b.get(o+k); got.add(new String(x, "UTF-8")); }
            else { int l = b.getShort(o) & 0xFFFF; char[] c = new char[l]; for (int k=0;k<l;k++) c[k]=(char)(b.getShort(o+2+2*k)&0xFFFF); got.add(new String(c)); }
        }
        check(got.contains("id.bagus.aplikasi_saya") && got.contains("Aplikasi Saya \u00e9\u4e2d"), "string pool terganti: " + got.get(5) + " | " + got.get(6));
        check(!got.contains("__APP_NAME__") && !got.contains("com.html2apk.placeholder"), "placeholder hilang");
        int el = 8 + 12 + poolSize - 12 + 0; // awal elemen = 8 + poolSize
        el = 8 + poolSize;
        check((b.getShort(el) & 0xFFFF) == 0x0102, "chunk elemen mulai tepat setelah pool");
        int vc = el + 16 + 20 + 20; // atribut ke-2
        check(b.getInt(vc + 16) == 4242 && b.get(vc + 15) == 0x10, "versionCode = 4242 (int)");
        try { AxmlPatcher.patch(src, Map.of("tidak_ada", "x"), 1); check(false, "harus gagal"); } catch (java.io.IOException e) { check(true, "placeholder hilang ditolak"); }
    }
}
