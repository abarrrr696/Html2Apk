package com.html2apk.builder;

import java.io.*;
import java.util.*;
import java.util.zip.*;

public class ApkTest {
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); System.out.println("OK  " + msg); }
    public static void main(String[] a) throws Exception {
        File tpl = File.createTempFile("tpl", ".apk");
        ZipWriter z = new ZipWriter(new FileOutputStream(tpl));
        z.add("AndroidManifest.xml", CoreTest.buildAxml(false), false);
        z.add("resources.arsc", new byte[500], true);
        z.add("classes.dex", new byte[2000], false);
        z.add(ApkBuilder.ICON_ENTRY, new byte[]{1, 2, 3}, false);
        z.add("META-INF/OLD.SF", new byte[]{1}, false);
        z.close();

        ApkBuilder.Config c = new ApkBuilder.Config();
        c.appName = "Toko Saya"; c.pkg = "com.toko.saya"; c.versionName = "2.1"; c.versionCode = 7;
        c.license = "MIT"; c.iconPng = new byte[]{9, 8, 7, 6}; c.extraConfig = "orientation=auto\nfullscreen=true\n";
        check(ApkBuilder.validate(c, "com.html2apk.builder") == null, "validasi lolos");
        c.pkg = "Toko.Saya"; check("v.pkg".equals(ApkBuilder.validate(c, "x")), "paket huruf besar ditolak (kunci v.pkg)");
        c.pkg = "toko"; check("v.pkg".equals(ApkBuilder.validate(c, "x")), "paket satu bagian ditolak");
        c.pkg = "com.html2apk.builder"; check("v.pkgown".equals(ApkBuilder.validate(c, "com.html2apk.builder")), "paket milik pembuat ditolak");
        c.pkg = "com.toko.saya";

        List<ApkBuilder.Asset> www = new ArrayList<>();
        www.add(asset("index.html", "<html></html>"));
        www.add(asset("css/style.css", "body{}"));
        www.add(asset("js/app.js", "console.log(1)"));
        File out = File.createTempFile("out", ".apk");
        ApkBuilder.buildUnsigned(tpl, www, c, out);
        try (ZipFile zf = new ZipFile(out)) {
            List<String> names = new ArrayList<>();
            for (Enumeration<? extends ZipEntry> e = zf.entries(); e.hasMoreElements();) names.add(e.nextElement().getName());
            System.out.println("    " + names);
            check(names.contains("assets/www/css/style.css") && names.contains("assets/www/js/app.js"), "CSS dan JS multi-file masuk");
            check(!names.contains("META-INF/OLD.SF"), "tanda tangan lama dibuang");
            check(Arrays.equals(zf.getInputStream(zf.getEntry(ApkBuilder.ICON_ENTRY)).readAllBytes(), c.iconPng), "ikon diganti");
            check(new String(zf.getInputStream(zf.getEntry("assets/LICENSE.txt")).readAllBytes()).equals("MIT"), "lisensi masuk");
            check(new String(zf.getInputStream(zf.getEntry("assets/config.properties")).readAllBytes()).contains("fullscreen=true"), "config.properties masuk");
        }
        // tanpa index.html -> gagal dan file output bersih
        File out2 = File.createTempFile("out", ".apk");
        try { ApkBuilder.buildUnsigned(tpl, Collections.singletonList(asset("x.html", "a")), c, out2); check(false, "harus gagal"); }
        catch (IOException e) { check(!out2.exists(), "tanpa index.html ditolak, file sisa dihapus"); }
        i18n();
        Process p = new ProcessBuilder("unzip", "-tq", out.getPath()).redirectErrorStream(true).start();
        String s = new String(p.getInputStream().readAllBytes()); p.waitFor();
        check(s.contains("No errors"), "unzip -t bersih");
    }
    static void i18n() {
        int n = 0;
        for (String k : I18n.keys()) { I18n.en = false; String a = I18n.t(k); I18n.en = true; String b = I18n.t(k); check(!a.isEmpty() && !b.isEmpty(), "i18n " + k); n++; }
        I18n.en = true; check(I18n.f("e.fail", "x").equals("Failed: x"), "format EN"); I18n.en = false; check(I18n.f("e.fail", "x").equals("Gagal: x"), "format ID");
        System.out.println("    " + n + " kunci terjemahan lengkap");
    }
    static ApkBuilder.Asset asset(final String p, final String t) {
        return new ApkBuilder.Asset() { public String path() { return p; } public byte[] read() { return t.getBytes(); } };
    }
}
