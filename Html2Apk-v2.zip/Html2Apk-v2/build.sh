#!/usr/bin/env bash
# Membangun Html2Apk.apk (aplikasi pembuat) tanpa gradle.
# Variabel opsional: ANDROID_SDK, BUILD_TOOLS, PLATFORM, AAPT
set -euo pipefail
cd "$(dirname "$0")"

SDK="${ANDROID_SDK:-$HOME/android-sdk}"
BT_VER="${BUILD_TOOLS:-33.0.2}"
PLATFORM="${PLATFORM:-android-33}"
BT="$SDK/build-tools/$BT_VER"
JAR="$SDK/platforms/$PLATFORM/android.jar"
APKSIG="$BT/lib/apksigner.jar"

die() { echo "GAGAL: $*" >&2; exit 1; }
[ -f "$JAR" ]    || die "android.jar tidak ada: $JAR"
[ -f "$APKSIG" ] || die "apksigner.jar tidak ada: $APKSIG"
[ -e "$BT/d8" ]  || die "d8 tidak ada di $BT"
command -v javac >/dev/null || die "javac tidak ada (sudo apt install default-jdk)"

pick_aapt() {
  for c in "${AAPT:-}" "$BT/aapt" aapt; do
    [ -n "$c" ] && "$c" version >/dev/null 2>&1 && { echo "$c"; return 0; }
  done
  return 1
}
pick_zipalign() {
  local o
  for c in "$BT/zipalign" zipalign; do
    o="$("$c" 2>&1 || true)"
    case "$o" in *[Zz]ip\ [Aa]lignment*) echo "$c"; return 0;; esac
  done
  return 1
}
AAPT="$(pick_aapt)"        || die "aapt tidak bisa dijalankan. Coba: sudo apt install aapt  (aapt SDK itu x86_64; di Kali ARM harus pakai paket Debian)"
ZIPALIGN="$(pick_zipalign)" || die "zipalign tidak bisa dijalankan. Coba: sudo apt install zipalign"
echo "aapt     : $AAPT"
echo "zipalign : $ZIPALIGN"

# Key untuk menandatangani aplikasi pembuat ini saja (bukan key APK hasil buatan).
KS_DIR="$HOME/.html2apk"; KS="$KS_DIR/builder.jks"; PASSF="$KS_DIR/builder.pass"
if [ ! -f "$KS" ]; then
  echo "Membuat key penanda tangan di $KS"
  mkdir -p "$KS_DIR"
  ( umask 077
    head -c 18 /dev/urandom | base64 | tr -d '/+=' > "$PASSF"
    keytool -genkeypair -keystore "$KS" -storetype PKCS12 -alias apk -keyalg RSA -keysize 3072 \
      -validity 10950 -dname "CN=Html2Apk Builder" \
      -storepass:file "$PASSF" -keypass:file "$PASSF" )
fi

rm -rf out
mkdir -p out/t/obj out/t/dex out/b/obj out/b/dex out/b/assets

echo "== 1/2 Template WebView =="
javac --release 8 -cp "$JAR" -d out/t/obj $(find template/src -name '*.java')
# javac 21 menulis MethodParameters tanpa nama; d8 lama (build-tools 33) crash karenanya.
java tools/StripMethodParameters.java out/t/obj
"$BT/d8" --min-api 21 --lib "$JAR" --output out/t/dex $(find out/t/obj -name '*.class')
"$AAPT" package -f -M template/AndroidManifest.xml -S template/res -I "$JAR" \
  --min-sdk-version 21 --target-sdk-version 34 -F out/template.apk
( cd out/t/dex && "$AAPT" add ../../template.apk classes.dex >/dev/null )

# Pemeriksaan: placeholder harus utuh dan ikon harus di jalur yang diganti builder.
"$AAPT" dump xmltree out/template.apk AndroidManifest.xml > out/manifest.txt
for k in com.html2apk.placeholder __APP_NAME__ 0.0.0-placeholder versionCode; do
  grep -q "$k" out/manifest.txt || die "template: '$k' tidak ada di manifest hasil aapt"
done
unzip -l out/template.apk | grep -q " res/drawable/ic_launcher.png" \
  || die "template: ikon tidak berada di res/drawable/ic_launcher.png"
unzip -l out/template.apk | grep -q " resources.arsc" || die "template: resources.arsc tidak ada"

echo "== 2/2 Aplikasi pembuat =="
cp out/template.apk out/b/assets/template.apk
javac --release 8 -cp "$JAR:$APKSIG" -d out/b/obj $(find builder/src -name '*.java')
java tools/StripMethodParameters.java out/b/obj
"$BT/d8" --min-api 29 --lib "$JAR" --output out/b/dex $(find out/b/obj -name '*.class') "$APKSIG"
[ -f out/b/dex/classes.dex ] || die "d8 tidak menghasilkan classes.dex"
"$AAPT" package -f -M builder/AndroidManifest.xml -S builder/res -A out/b/assets -I "$JAR" \
  --min-sdk-version 29 --target-sdk-version 34 -F out/builder.unsigned.apk
( cd out/b/dex && "$AAPT" add ../../builder.unsigned.apk classes.dex >/dev/null )
for extra in out/b/dex/classes2.dex; do
  [ -f "$extra" ] && ( cd out/b/dex && "$AAPT" add ../../builder.unsigned.apk classes2.dex >/dev/null )
done || true

"$ZIPALIGN" -f -p 4 out/builder.unsigned.apk out/builder.aligned.apk
"$BT/apksigner" sign --ks "$KS" --ks-key-alias apk --ks-pass "file:$PASSF" \
  --out out/Html2Apk.apk out/builder.aligned.apk
"$BT/apksigner" verify --print-certs out/Html2Apk.apk | head -4

echo
echo "SELESAI: $(pwd)/out/Html2Apk.apk  ($(du -h out/Html2Apk.apk | cut -f1))"
echo "Pindahkan ke HP (adb install out/Html2Apk.apk atau salin manual)."
