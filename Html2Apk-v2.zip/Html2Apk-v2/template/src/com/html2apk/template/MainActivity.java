package com.html2apk.template;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Menampilkan assets/www/index.html lewat https://app.local/ (dilayani dari assets).
 * Pengaturan dibaca dari assets/config.properties yang ditulis Html2Apk.
 * Akses file:// dimatikan; fetch(), modul JS, localStorage, dan seek audio/video (Range) berfungsi.
 */
public class MainActivity extends Activity {
    private static final String HOST = "app.local";
    private WebView web;
    private boolean offline, openExternal = true, fullscreen;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Properties cfg = loadConfig();
        offline = bool(cfg, "offline", false);
        openExternal = bool(cfg, "externalBrowser", true);
        fullscreen = bool(cfg, "fullscreen", false);
        int color = Color.BLACK;
        try {
            color = Color.parseColor(cfg.getProperty("color", "#000000"));
        } catch (Exception ignored) {
        }

        String o = cfg.getProperty("orientation", "auto");
        if ("portrait".equals(o)) setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        else if ("landscape".equals(o)) setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        if (bool(cfg, "keepOn", false)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        getWindow().setStatusBarColor(color);
        getWindow().setNavigationBarColor(color);
        getWindow().getDecorView().setBackgroundColor(color);
        double lum = 0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color);
        if (lum > 160 && Build.VERSION.SDK_INT >= 23) {
            int f = getWindow().getDecorView().getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            getWindow().getDecorView().setSystemUiVisibility(f);
        }

        web = new WebView(this);
        web.setBackgroundColor(color);
        setContentView(web);

        boolean zoom = bool(cfg, "zoom", false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(zoom);
        s.setBuiltInZoomControls(zoom);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new WebChromeClient());
        if (state == null) web.loadUrl("https://" + HOST + "/index.html");
        else web.restoreState(state);
    }

    private Properties loadConfig() {
        Properties p = new Properties();
        try {
            InputStream in = getAssets().open("config.properties");
            try {
                p.load(in);
            } finally {
                in.close();
            }
        } catch (IOException ignored) {
        }
        return p;
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : "true".equals(v.trim());
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && fullscreen) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }

    private class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (!HOST.equals(u.getHost())) {
                String sc = u.getScheme();
                if (offline && ("http".equals(sc) || "https".equals(sc))) return status(403, "Forbidden");
                return null;
            }
            String path = u.getPath();
            if (path == null || path.length() <= 1) path = "/index.html";
            String rel = path.substring(1);
            if (rel.contains("..")) return status(404, "Not Found");
            try {
                return serve(rel, r.getRequestHeaders().get("Range"));
            } catch (IOException e) {
                return status(404, "Not Found");
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (HOST.equals(u.getHost()) || !openExternal) return false;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (Exception ignored) {
            }
            return true;
        }
    }

    private WebResourceResponse serve(String rel, String range) throws IOException {
        InputStream in = getAssets().open("www/" + rel);
        String mime = mimeOf(rel);
        boolean text = mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") || mime.contains("xml");
        Map<String, String> h = new HashMap<String, String>();
        h.put("Accept-Ranges", "bytes");
        if (range != null && range.startsWith("bytes=")) {
            long total = in.available();
            try {
                String[] r = range.substring(6).split("-", 2);
                long start = r[0].isEmpty() ? 0 : Long.parseLong(r[0].trim());
                long end = (r.length > 1 && !r[1].trim().isEmpty()) ? Long.parseLong(r[1].trim()) : total - 1;
                if (end >= total) end = total - 1;
                if (start <= end && total > 0) {
                    long skipped = 0;
                    while (skipped < start) {
                        long n = in.skip(start - skipped);
                        if (n <= 0) break;
                        skipped += n;
                    }
                    if (skipped == start) {
                        long len = end - start + 1;
                        h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
                        h.put("Content-Length", String.valueOf(len));
                        return new WebResourceResponse(mime, null, 206, "Partial Content", h, new Limited(in, len));
                    }
                }
            } catch (NumberFormatException ignored) {
            }
            in.close();
            in = getAssets().open("www/" + rel);
        }
        return new WebResourceResponse(mime, text ? "utf-8" : null, 200, "OK", h, in);
    }

    private static final class Limited extends FilterInputStream {
        private long left;

        Limited(InputStream in, long len) {
            super(in);
            left = len;
        }

        @Override
        public int read() throws IOException {
            if (left <= 0) return -1;
            int b = super.read();
            if (b >= 0) left--;
            return b;
        }

        @Override
        public int read(byte[] buf, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = super.read(buf, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            return n;
        }
    }

    private static WebResourceResponse status(int code, String reason) {
        return new WebResourceResponse("text/plain", "utf-8", code, reason,
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private static String mimeOf(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        if (n.endsWith(".js") || n.endsWith(".mjs")) return "text/javascript";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".json") || n.endsWith(".map")) return "application/json";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".wasm")) return "application/wasm";
        if (n.endsWith(".woff2")) return "font/woff2";
        if (n.endsWith(".woff")) return "font/woff";
        if (n.endsWith(".ttf")) return "font/ttf";
        if (n.endsWith(".mp3")) return "audio/mpeg";
        if (n.endsWith(".webmanifest")) return "application/manifest+json";
        int dot = n.lastIndexOf('.');
        String m = dot >= 0 ? MimeTypeMap.getSingleton().getMimeTypeFromExtension(n.substring(dot + 1)) : null;
        return m != null ? m : "application/octet-stream";
    }
}
