#!/usr/bin/env bash
# Uji bagian inti (tanpa Android): ZIP rata 4 byte, penambal manifest biner, key + sertifikat, perakit APK.
set -euo pipefail
cd "$(dirname "$0")"
B=builder/src/com/html2apk/builder
rm -rf out/test && mkdir -p out/test
javac -d out/test $B/I18n.java $B/ZipWriter.java $B/AxmlPatcher.java $B/KeyStoreManager.java $B/ApkBuilder.java test/CoreTest.java test/ApkTest.java
java -cp out/test com.html2apk.builder.CoreTest
java -cp out/test com.html2apk.builder.ApkTest
